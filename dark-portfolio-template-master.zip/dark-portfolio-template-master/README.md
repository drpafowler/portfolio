# Dark Portfolio Template

A minimal template built from scratch as a prototype for [another project](https://github.com/MLH-Fellowship/FellowshipWrapup) I was working on.

Use it, customize it or _fix it_, it's free for use lads.

![screenshot](https://user-images.githubusercontent.com/48270786/88185087-2269d580-cc51-11ea-9781-b0dab9d41200.png)
